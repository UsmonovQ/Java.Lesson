import java.util.Scanner;

public class Recursia {
    public static void main(String[] args) {
        //Используя рекурсию, написать метод вычисления факториала числа n (n!),
        // вводимого с клавиатуры
        Scanner scr=new Scanner(System.in);
        int num = scr.nextInt();
        int num1=factorialCalculator(num);
        System.out.println(num1);
    }

    private static int factorialCalculator(int n){
        if (n==0){
            return 1;
        } else return n * factorialCalculator(n - 1);
    }
}
