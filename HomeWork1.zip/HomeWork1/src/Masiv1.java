import java.util.Arrays;
public class Masiv1 {
    public static void main(String[] args) {
        //Создайте массив из 5 строк. Используя метод length() строк,
        // найдите строку с наибольшей длиной и строк с наименьшей длиной.
        //Выведите массив и полученный строки в консоль.
        String[] word = {"Qiyomiddin", "Anton", "Vadim", "Il`iya", "Svetlana"};
        String minLengthString = findMin(word);
        String maxLengthString = findMax(word);
        System.out.println("Исходный массив:");
        System.out.println(Arrays.toString(word));
        System.out.println("Строка с наибольшей длиной: " + maxLengthString);
        System.out.println("Строка с наименьшей длиной: " + minLengthString);

    }

    private static String findMax(String[] array) {
        String maximum = array[0];
        for (String str : array) {
            if (str.length() > maximum.length()) {
                maximum = str;
            }
        }
        return maximum;
    }

    private static String findMin(String[] array) {
        String minimum = array[0];
        for (String str : array) {
            if (str.length() < minimum.length()) {
                minimum = str;
            }
        }
        return minimum;
    }
}
