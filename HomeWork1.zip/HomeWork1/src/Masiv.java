import java.util.Arrays;
import java.util.Random;

public class Masiv {
    public static void main(String[] args) {
        //Задание 3.
        //Создайте массив из 8 случайных целых чисел из интервала [1;50]
        //Выведите массив в консоль в строку.
        //Замените каждый элемент с нечетным индексом на ноль.
        //Снова выведете массив в консоль в отдельной строке.
        //Отсортируйте массив по возрастанию.
        //Снова выведете массив в консоль в отдельной строке.
        int[] numbers = new int[8];
        Random rnd = new Random();
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = rnd.nextInt(50) + 1;
        }
        System.out.println("1) Nash masiv v vide stroka:" + Arrays.toString(numbers));
        for (int i = 1; i < numbers.length; i += 2) {
            numbers[i] = 0;
        }
        System.out.println("2) Masiv posle zameni nechetnikh elementov na nol:" + Arrays.toString(numbers));
        Arrays.sort(numbers);
        System.out.println("3) Vivod masiv v stroke(posle sortirovki): " + Arrays.toString(numbers));
    }
}
