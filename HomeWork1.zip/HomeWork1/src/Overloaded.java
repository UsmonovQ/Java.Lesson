public class Overloaded {
    public static void main(String[] args) {
        //Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
        // В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
        // В методе умножения 4-х чисел – вызов метода для 3-х чисел.
        int sum1 = getSum(10, 20);
        int sum2 = getSum(10, 20, 30);
        int sum3 = getSum(10, 20, 30, 40);
        System.out.println("Результат умножения двух чисел: " + sum1);
        System.out.println("Результат умножения трех чисел: " + sum2);
        System.out.println("Результат умножения четырех чисел: " + sum3);
    }

    private static int getSum(int a, int b) {
        return a * b;

    }

    private static int getSum(int num1, int num2, int num3) {
        int abc = getSum(num1, num2);
        return abc * num3;
    }

    private static int getSum(int num1, int num2, int num3, int num4) {
        int abc = getSum(num1, num2, num3);
        return abc * num4;
    }
}